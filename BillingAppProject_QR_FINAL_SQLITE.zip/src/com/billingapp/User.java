package com.billingapp;

import javafx.beans.property.*;

public class User {
    private final IntegerProperty id;
    private final StringProperty username;
    private final StringProperty password;
    private final StringProperty role;
    private final StringProperty displayName;

    // --- Constructors ---
    public User() {
        this(0, "", "", "USER", "");
    }

    public User(int id, String username, String password, String role, String displayName) {
        this.id = new SimpleIntegerProperty(id);
        this.username = new SimpleStringProperty(username);
        this.password = new SimpleStringProperty(password);
        this.role = new SimpleStringProperty(role);
        this.displayName = new SimpleStringProperty(displayName);
    }

    // --- ID ---
    public int getId() { return id.get(); }
    public void setId(int id) { this.id.set(id); }
    public IntegerProperty idProperty() { return id; }

    // --- Username ---
    public String getUsername() { return username.get(); }
    public void setUsername(String username) { this.username.set(username); }
    public StringProperty usernameProperty() { return username; }

    // --- Password ---
    public String getPassword() { return password.get(); }
    public void setPassword(String password) { this.password.set(password); }
    public StringProperty passwordProperty() { return password; }

    // --- Role ---
    public String getRole() { return role.get(); }
    public void setRole(String role) { this.role.set(role); }
    public StringProperty roleProperty() { return role; }

    // --- Display Name ---
    public String getDisplayName() { return displayName.get(); }
    public void setDisplayName(String displayName) { this.displayName.set(displayName); }
    public StringProperty displayNameProperty() { return displayName; }

    @Override
    public String toString() {
        return "User{" +
                "id=" + getId() +
                ", username='" + getUsername() + '\'' +
                ", role='" + getRole() + '\'' +
                ", displayName='" + getDisplayName() + '\'' +
                '}';
    }
}
