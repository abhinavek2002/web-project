package com.billingapp;

import java.sql.*;

public class DBConnection {
    private static Connection conn = null;

    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection("jdbc:sqlite:billing.db");
                initDB();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    private static void initDB() {
        try (Statement st = conn.createStatement()) {

            // --- Products table ---
            st.execute("CREATE TABLE IF NOT EXISTS products (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "sku TEXT UNIQUE, " +
                    "name TEXT UNIQUE, " +
                    "textile_type TEXT, " +
                    "hsn_sac TEXT, " +
                    "unit_price REAL, " +
                    "unit TEXT, " +
                    "stock REAL, " +
                    "discount REAL" +
                    ")");

            // --- Transactions table ---
            st.execute("CREATE TABLE IF NOT EXISTS transactions (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "details TEXT, " +
                    "created_at TEXT DEFAULT CURRENT_TIMESTAMP" +
                    ")");

            // --- Users table ---
            st.execute("CREATE TABLE IF NOT EXISTS users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT NOT NULL UNIQUE, " +
                    "password TEXT NOT NULL, " +
                    "role TEXT NOT NULL, " +
                    "display_name TEXT" +
                    ")");

            // --- Default data for products ---
            ResultSet rs = st.executeQuery("SELECT COUNT(*) AS c FROM products");
            if (rs.next() && rs.getInt("c") == 0) {
                st.execute("INSERT INTO products (sku, name, textile_type, hsn_sac, unit_price, unit, stock, discount) VALUES " +
                        "('SKU-1', 'Pens', 'Stationery', '4901', 10.0, 'pcs', 100, 0)");
                st.execute("INSERT INTO products (sku, name, textile_type, hsn_sac, unit_price, unit, stock, discount) VALUES " +
                        "('SKU-2', 'Notebook', 'Stationery', '4820', 40.0, 'pcs', 50, 5)");
                st.execute("INSERT INTO products (sku, name, textile_type, hsn_sac, unit_price, unit, stock, discount) VALUES " +
                        "('SKU-3', 'Stapler', 'Office', '8472', 120.0, 'pcs', 20, 10)");
            }

            // --- Default data for users ---
            rs = st.executeQuery("SELECT COUNT(*) AS c FROM users");
            if (rs.next() && rs.getInt("c") == 0) {
                st.execute("INSERT INTO users (username, password, role, display_name) VALUES " +
                        "('admin', '1234', 'ADMIN', 'Administrator'), " +
                        "('john', '1234', 'USER', 'John Doe')");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
