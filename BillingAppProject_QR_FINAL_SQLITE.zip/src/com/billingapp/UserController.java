package com.billingapp;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

public class UserController {

    // 🎯 These match your FXML input IDs (from Login.fxml)
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    // 🔹 Called when user clicks "Login" button
    @FXML
    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.equals("admin") && password.equals("admin")) {
            openAdminPanel();
        } else if (username.equals("user") && password.equals("user")) {
            openUserPanel();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid username or password!");
            alert.showAndWait();
        }
    }

    // ✅ Open Admin Panel (AdminPanelFX)
    private void openAdminPanel() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/billingapp/fxml/AdminPanel.fxml"));
            Scene scene = new Scene(loader.load());
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("BillingApp - Admin Panel");
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load Admin Panel!");
            alert.showAndWait();
        }
    }

    // ✅ Open User Panel (UserPanelFX)
    private void openUserPanel() {
        try {
            UserPanelFX userPanel = new UserPanelFX();
            Scene scene = new Scene(userPanel, 900, 600);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(scene);
            stage.setTitle("BillingApp - User Panel");
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load User Panel!");
            alert.showAndWait();
        }
    }
}
