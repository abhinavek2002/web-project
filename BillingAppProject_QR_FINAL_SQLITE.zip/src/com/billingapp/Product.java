package com.billingapp;

/**
 * Represents a product in the billing system.
 * Compatible with both AdminPanel and UserPanelFX.
 */
public class Product {
    private int id;
    private String sku;
    private String name;
    private String textileType;
    private String hsnSac;
    private double unitPrice;
    private String unit;
    private double stock;
    private double discount;

    // ====================================================
    // 🔹 Constructors
    // ====================================================

    /** Empty constructor (required for FX reflection) */
    public Product() {}

    /** Minimal constructor (used in AdminPanel / test data) */
    public Product(int id, String name, double price, double stock, double discount) {
        this.id = id;
        this.name = name;
        this.unitPrice = price;
        this.stock = stock;
        this.discount = discount;
    }

    /** Full textile constructor (used when loading from DB) */
    public Product(int id, String sku, String name, String textileType, String hsnSac,
                   double unitPrice, String unit, double stock, double discount) {
        this.id = id;
        this.sku = sku;
        this.name = name;
        this.textileType = textileType;
        this.hsnSac = hsnSac;
        this.unitPrice = unitPrice;
        this.unit = unit;
        this.stock = stock;
        this.discount = discount;
    }

    /** Simple non-id constructor (used for new product creation before saving) */
    public Product(String sku, String name, String textileType, String hsnSac,
                   double unitPrice, String unit, double stock) {
        this(0, sku, name, textileType, hsnSac, unitPrice, unit, stock, 0.0);
    }

    /** ✅ Added: Compatibility constructor for old UserPanelFX */
    public Product(int id, String name, String category, double price, double discount, double total) {
        this.id = id;
        this.name = name;
        this.textileType = category; // mapped to textileType
        this.unitPrice = price;
        this.discount = discount;
        this.stock = total; // 'stock' reused for total quantity
    }

    // ====================================================
    // 🔹 Getters & Setters
    // ====================================================

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getTextileType() { return textileType; }
    public void setTextileType(String textileType) { this.textileType = textileType; }

    public String getHsnSac() { return hsnSac; }
    public void setHsnSac(String hsnSac) { this.hsnSac = hsnSac; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public double getStock() { return stock; }
    public void setStock(double stock) { this.stock = stock; }

    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }

    // ====================================================
    // 🔹 Helper Methods
    // ====================================================

    /** Alias for compatibility with AdminPanel code */
    public double getPrice() { return unitPrice; }
    public void setPrice(double price) { this.unitPrice = price; }

    /** For displaying product name in UI dropdowns or list views */
    @Override
    public String toString() {
        return name + " (" + unitPrice + ")";
    }
}
