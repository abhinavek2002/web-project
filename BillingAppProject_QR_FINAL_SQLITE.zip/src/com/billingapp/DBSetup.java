package com.billingapp;

import java.sql.Connection;
import java.sql.Statement;

public class DBSetup {
    public static void main(String[] args) {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // Create users table if it does not exist
            String createUsersTable = """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL UNIQUE,
                    password TEXT NOT NULL,
                    role TEXT NOT NULL
                );
            """;
            stmt.execute(createUsersTable);

            // Create products table if it does not exist
            String createProductsTable = """
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    sku TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL,
                    type TEXT,
                    hsn TEXT,
                    price REAL,
                    unit TEXT,
                    stock INTEGER
                );
            """;
            stmt.execute(createProductsTable);

            // Insert default users only if they don't already exist
            stmt.executeUpdate("INSERT OR IGNORE INTO users (username, password, role) VALUES ('admin', '1234', 'ADMIN');");
            stmt.executeUpdate("INSERT OR IGNORE INTO users (username, password, role) VALUES ('john', '1234', 'USER');");

            System.out.println("✅ Database setup completed! (users + products)");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
