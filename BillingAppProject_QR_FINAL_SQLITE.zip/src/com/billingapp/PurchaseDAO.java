package com.billingapp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PurchaseDAO {
    private Connection conn;

    public PurchaseDAO(Connection conn) {
        this.conn = conn;
        createTableIfNotExists();
    }

    private void createTableIfNotExists() {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("""
                CREATE TABLE IF NOT EXISTS purchases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customerName TEXT,
                    productName TEXT,
                    quantity INTEGER,
                    total REAL,
                    paymentMethod TEXT
                )
            """);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean addPurchase(Purchase purchase) {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO purchases (customerName, productName, quantity, total, paymentMethod) VALUES (?, ?, ?, ?, ?)")) {
            ps.setString(1, purchase.getCustomerName());
            ps.setString(2, purchase.getProductName());
            ps.setInt(3, purchase.getQuantity());
            ps.setDouble(4, purchase.getTotal());
            ps.setString(5, purchase.getPaymentMethod());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Purchase> listAll() {
        List<Purchase> list = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM purchases")) {
            while (rs.next()) {
                list.add(new Purchase(
                        rs.getString("customerName"),
                        rs.getString("productName"),
                        rs.getInt("quantity"),
                        rs.getDouble("total"),
                        rs.getString("paymentMethod")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
