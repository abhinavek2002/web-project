package com.billingapp;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.function.Consumer;

/**
 * QR / Barcode Scanner using webcam and ZXing.
 * Opens a live preview window and continuously scans frames until a code is detected.
 */
public class QRScanner {

    public QRScanner(Consumer<String> onDetected) {
        new Thread(() -> {
            Webcam webcam = null;
            JFrame window = null;
            try {
                webcam = Webcam.getDefault();
                if (webcam == null) {
                    SwingUtilities.invokeLater(() ->
                            JOptionPane.showMessageDialog(null, "No webcam detected!")
                    );
                    return;
                }

                // Set webcam resolution
                webcam.setViewSize(WebcamResolution.VGA.getSize()); // 640x480 for better clarity
                webcam.open();

                // Create a live view panel
                WebcamPanel panel = new WebcamPanel(webcam);
                panel.setFPSDisplayed(true);
                panel.setMirrored(true);

                window = new JFrame("QR Scanner");
                window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                window.setLayout(new BorderLayout());
                window.add(panel, BorderLayout.CENTER);
                window.pack();
                window.setLocationRelativeTo(null);
                window.setVisible(true);

                System.out.println("Camera started, waiting for barcode...");

                boolean found = false;
                MultiFormatReader reader = new MultiFormatReader();

                while (!found) {
                    if (!webcam.isOpen()) {
                        System.out.println("Webcam closed unexpectedly.");
                        break;
                    }

                    BufferedImage image = webcam.getImage();
                    if (image == null) {
                        Thread.sleep(100);
                        continue;
                    }

                    LuminanceSource source = new BufferedImageLuminanceSource(image);
                    BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

                    try {
                        Result result = reader.decode(bitmap);
                        if (result != null) {
                            String text = result.getText();
                            System.out.println("✅ Barcode detected: " + text);
                            onDetected.accept(text);
                            found = true;
                        }
                    } catch (NotFoundException e) {
                        // No barcode found in this frame — keep scanning
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }

                    Thread.sleep(150); // small delay to prevent CPU overload
                }

            } catch (Exception e) {
                e.printStackTrace();
                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage())
                );
            } finally {
                if (webcam != null && webcam.isOpen()) {
                    webcam.close();
                    System.out.println("Webcam closed.");
                }
                if (window != null) {
                    SwingUtilities.invokeLater(window::dispose);
                }
            }
        }, "QR-Scanner-Thread").start();
    }
}
