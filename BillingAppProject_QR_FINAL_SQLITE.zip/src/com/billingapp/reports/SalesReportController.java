package com.billingapp.reports;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.billingapp.DBConnection;

public class SalesReportController {

    @FXML private TableView<SalesRecord> salesTable;
    @FXML private TableColumn<SalesRecord, String> dateCol;
    @FXML private TableColumn<SalesRecord, Integer> invoiceCol;
    @FXML private TableColumn<SalesRecord, String> partyCol;
    @FXML private TableColumn<SalesRecord, String> typeCol;
    @FXML private TableColumn<SalesRecord, Double> totalCol;
    @FXML private TableColumn<SalesRecord, String> paymentCol;
    @FXML private TableColumn<SalesRecord, Double> receivedCol;
    @FXML private TableColumn<SalesRecord, Double> balanceCol;
    @FXML private Label totalSaleLabel;
    @FXML private Label generatedLabel;

    private ObservableList<SalesRecord> data = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        invoiceCol.setCellValueFactory(new PropertyValueFactory<>("invoiceNo"));
        partyCol.setCellValueFactory(new PropertyValueFactory<>("partyName"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("transactionType"));
        totalCol.setCellValueFactory(new PropertyValueFactory<>("total"));
        paymentCol.setCellValueFactory(new PropertyValueFactory<>("paymentType"));
        receivedCol.setCellValueFactory(new PropertyValueFactory<>("received"));
        balanceCol.setCellValueFactory(new PropertyValueFactory<>("balanceDue"));

        loadData();
    }

    private void loadData() {
        double totalSale = 0.0;
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT date, invoice_no, party_name, transaction_type, total, payment_type, received, balance_due FROM sales";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                SalesRecord record = new SalesRecord(
                        rs.getString("date"),
                        rs.getInt("invoice_no"),
                        rs.getString("party_name"),
                        rs.getString("transaction_type"),
                        rs.getDouble("total"),
                        rs.getString("payment_type"),
                        rs.getDouble("received"),
                        rs.getDouble("balance_due")
                );
                data.add(record);
                totalSale += rs.getDouble("total");
            }
            salesTable.setItems(data);
            totalSaleLabel.setText("Total Sale: ₹ " + String.format("%,.2f", totalSale));
        } catch (Exception e) {
            e.printStackTrace();
        }

        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy 'at' h:mm a"));
        generatedLabel.setText("Generated on " + now);
    }
}
