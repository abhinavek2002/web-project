package com.billingapp.reports;

public class SalesRecord {
    private String date;
    private int invoiceNo;
    private String partyName;
    private String transactionType;
    private double total;
    private String paymentType;
    private double received;
    private double balanceDue;

    public SalesRecord(String date, int invoiceNo, String partyName, String transactionType,
                       double total, String paymentType, double received, double balanceDue) {
        this.date = date;
        this.invoiceNo = invoiceNo;
        this.partyName = partyName;
        this.transactionType = transactionType;
        this.total = total;
        this.paymentType = paymentType;
        this.received = received;
        this.balanceDue = balanceDue;
    }

    public String getDate() { return date; }
    public int getInvoiceNo() { return invoiceNo; }
    public String getPartyName() { return partyName; }
    public String getTransactionType() { return transactionType; }
    public double getTotal() { return total; }
    public String getPaymentType() { return paymentType; }
    public double getReceived() { return received; }
    public double getBalanceDue() { return balanceDue; }
}
