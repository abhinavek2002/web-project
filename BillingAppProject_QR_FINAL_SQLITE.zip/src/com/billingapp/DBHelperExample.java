package com.billingapp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHelperExample {
    private String dbUrl = "jdbc:sqlite:billing.db"; // relative to app working dir

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(dbUrl);
    }

    public boolean addCustomer(String name, String phone) {
        String sql = "INSERT OR IGNORE INTO customers(name, phone) VALUES(?,?)";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Customer getCustomerByPhone(String phone) {
        String sql = "SELECT id, name, phone FROM customers WHERE phone = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, phone);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Customer(rs.getInt("id"), rs.getString("name"), rs.getString("phone"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Customer> searchCustomers(String q) {
        List<Customer> list = new ArrayList<>();
        String sql = "SELECT id, name, phone FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            String p = "%" + q + "%";
            pstmt.setString(1, p);
            pstmt.setString(2, p);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                list.add(new Customer(rs.getInt("id"), rs.getString("name"), rs.getString("phone")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
