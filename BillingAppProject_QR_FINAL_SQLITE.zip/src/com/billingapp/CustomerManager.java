package com.billingapp;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Simple text-file based customer manager.
 * Each line in customers.txt has the format:
 * Name,Phone
 *
 * Usage (example):
 *   CustomerManager.saveCustomer("Priya Sharma", "9123456789", "customers.txt");
 *   Optional: Map<String,String> found = CustomerManager.findCustomer("9123456789", "customers.txt");
 */
public class CustomerManager {

    // Ensure file exists
    private static void ensureFile(String filename) throws IOException {
        Path p = Paths.get(filename);
        if (!Files.exists(p)) {
            Files.createFile(p);
        }
    }

    // Save a customer (appends). Does not create duplicates check.
    public static void saveCustomer(String name, String phone, String filename) throws IOException {
        ensureFile(filename);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))) {
            bw.write(name.replaceAll("[\\r\\n,]"," ") + "," + phone.replaceAll("[\\r\\n,]"," "));
            bw.newLine();
        }
    }

    // Find a customer by name or phone (case-insensitive partial match).
    // Returns the first matching entry as a Map with keys "name" and "phone", or null if not found.
    public static Map<String,String> findCustomer(String query, String filename) throws IOException {
        ensureFile(filename);
        String q = query.trim().toLowerCase();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 2);
                if (parts.length < 2) continue;
                String name = parts[0].trim();
                String phone = parts[1].trim();
                if (name.toLowerCase().contains(q) || phone.toLowerCase().contains(q)) {
                    Map<String,String> out = new HashMap<>();
                    out.put("name", name);
                    out.put("phone", phone);
                    return out;
                }
            }
        }
        return null;
    }

    // Read all customers (returns list of maps)
    public static List<Map<String,String>> listAll(String filename) throws IOException {
        ensureFile(filename);
        List<Map<String,String>> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", 2);
                if (parts.length < 2) continue;
                Map<String,String> m = new HashMap<>();
                m.put("name", parts[0].trim());
                m.put("phone", parts[1].trim());
                list.add(m);
            }
        }
        return list;
    }
}