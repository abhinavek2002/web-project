package com.billingapp;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.sql.Connection;
import javafx.scene.layout.GridPane;

public class LoginController {

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label messageLabel;

    private Connection conn;

    @FXML
    public void initialize() {
        conn = DBConnection.getConnection();
    }

    // ===================== MAIN LOGIN HANDLER =====================
    @FXML
    public void onLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        try {
            // --- ADMIN LOGIN ---
            if ("admin".equalsIgnoreCase(username)) {
                handleAdminLogin();
                return;
            }

            // --- NORMAL USER LOGIN ---
            UserDAO userDAO = new UserDAO(conn);
            User user = userDAO.authenticate(username, password);

            if (user != null) {
                openPanel("/com/billingapp/fxml/user_panel.fxml", "User Panel");
                closeWindow();
            } else {
                messageLabel.setText("⚠ Invalid username or password!");
            }

        } catch (Exception ex) {
            messageLabel.setText("Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // ===================== ADMIN LOGIN POPUP =====================
    private void handleAdminLogin() {
        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Admin Login");
        dialog.setHeaderText("Enter Admin Password");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Password:"), 0, 0);
        grid.add(passwordField, 1, 0);

        dialog.getDialogPane().setContent(grid);

        ButtonType loginButtonType = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType changePassButtonType = new ButtonType("Change Password", ButtonBar.ButtonData.LEFT);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, changePassButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return passwordField.getText();
            } else if (dialogButton == changePassButtonType) {
                return "CHANGE";
            }
            return null;
        });

        String result = dialog.showAndWait().orElse(null);

        if (result != null && !result.equals("CHANGE")) {
            if (AdminAuth.checkPassword(result)) {
                try {
                    openPanel("/com/billingapp/fxml/admin_panel.fxml", "Admin Panel");
                    closeWindow();
                } catch (Exception e) {
                    e.printStackTrace();
                    showAlert("Error", "Unable to open Admin Panel: " + e.getMessage(), Alert.AlertType.ERROR);
                }
            } else {
                new Alert(Alert.AlertType.ERROR, "❌ Incorrect password!").showAndWait();
            }
        }

        if ("CHANGE".equals(result)) {
            showChangePasswordDialog();
        }
    }

    // ===================== CHANGE PASSWORD DIALOG =====================
    public void showChangePasswordDialog() { // <-- FIXED: made public
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Change Admin Password");
        dialog.setHeaderText("Change Your Password");

        PasswordField currentField = new PasswordField();
        PasswordField newField = new PasswordField();
        PasswordField confirmField = new PasswordField();

        currentField.setPromptText("Current Password");
        newField.setPromptText("New Password");
        confirmField.setPromptText("Confirm New Password");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Current Password:"), 0, 0);
        grid.add(currentField, 1, 0);
        grid.add(new Label("New Password:"), 0, 1);
        grid.add(newField, 1, 1);
        grid.add(new Label("Confirm Password:"), 0, 2);
        grid.add(confirmField, 1, 2);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> dialogButton);

        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                String current = currentField.getText().trim();
                String newPass = newField.getText().trim();
                String confirm = confirmField.getText().trim();

                if (!AdminAuth.checkPassword(current)) {
                    new Alert(Alert.AlertType.ERROR, "❌ Current password incorrect!").showAndWait();
                    return;
                }

                if (newPass.isEmpty() || confirm.isEmpty()) {
                    new Alert(Alert.AlertType.ERROR, "⚠ Please fill all fields!").showAndWait();
                    return;
                }

                if (!newPass.equals(confirm)) {
                    new Alert(Alert.AlertType.ERROR, "⚠ Passwords do not match!").showAndWait();
                    return;
                }

                AdminAuth.changePassword(newPass);
                new Alert(Alert.AlertType.INFORMATION, "✅ Password changed successfully!").showAndWait();
            }
        });
    }

    // ===================== WINDOW & ALERT HELPERS =====================
    @FXML
    public void onCancel() {
        closeWindow();
    }

    private void closeWindow() {
        Stage stage = (Stage) usernameField.getScene().getWindow();
        if (stage != null) stage.close();
    }

    private void openPanel(String fxmlPath, String title) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
        Parent root = loader.load();

        Stage st = new Stage();
        st.setTitle(title);
        st.setScene(new Scene(root));
        st.show();
    }

    private void showAlert(String title, String msg, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
