package com.billingapp;

public class CartItem {
    private Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int q) { this.quantity = q; }

    public double getTotal() {
        double price = product.getPrice();
        double d = product.getDiscount();
        double net = price - (price * d / 100.0);
        return net * quantity;
    }
}
