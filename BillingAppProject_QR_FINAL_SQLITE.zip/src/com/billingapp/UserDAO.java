package com.billingapp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
    private Connection conn;

    public UserDAO(Connection conn) {
        this.conn = conn;
    }

    /**
     * Authenticate a user with username + password.
     * Returns a User object if credentials match, null otherwise.
     */
    public User authenticate(String username, String password) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User u = new User();
                    u.setId(rs.getInt("id"));
                    u.setUsername(rs.getString("username"));
                    u.setRole(rs.getString("role"));

                    // Safe fallback for display_name
                    String displayName = null;
                    try {
                        displayName = rs.getString("display_name");
                    } catch (SQLException ignored) { }
                    u.setDisplayName(displayName != null ? displayName : u.getUsername());

                    return u;
                }
            }
        }
        return null;
    }
}
