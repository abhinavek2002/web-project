package com.billingapp;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;

import java.sql.Connection;
import java.util.List;

public class AdminPanelController {

    // --- Product Fields ---
    @FXML private TextField nameField;
    @FXML private TextField typeField;
    @FXML private TextField hsnField;
    @FXML private TextField priceField;
    @FXML private TextField unitField;
    @FXML private TextField stockField;
    @FXML private Label addMsg;

    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, String> nameCol;
    @FXML private TableColumn<Product, String> typeCol;
    @FXML private TableColumn<Product, String> hsnCol;
    @FXML private TableColumn<Product, Double> priceCol;
    @FXML private TableColumn<Product, String> unitCol;
    @FXML private TableColumn<Product, Double> stockCol;

    private ProductDAO productDAO;

    // --- Purchase Fields ---
    @FXML private TextField customerField;
    @FXML private TextField purchaseProductField;
    @FXML private TextField quantityField;
    @FXML private ComboBox<String> paymentMethodBox;
    @FXML private Label purchaseMsg;

    @FXML private TableView<Purchase> purchaseTable;
    @FXML private TableColumn<Purchase, String> customerCol;
    @FXML private TableColumn<Purchase, String> productCol;
    @FXML private TableColumn<Purchase, Integer> quantityCol;
    @FXML private TableColumn<Purchase, Double> totalCol;
    @FXML private TableColumn<Purchase, String> paymentCol;

    private PurchaseDAO purchaseDAO;

    @FXML
    public void initialize() {
        Connection conn = DBConnection.getConnection();
        productDAO = new ProductDAO(conn);
        purchaseDAO = new PurchaseDAO(conn);

        // --- Product table bindings ---
        nameCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
        typeCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getTextileType()));
        hsnCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getHsnSac()));
        priceCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getUnitPrice()).asObject());
        unitCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getUnit()));
        stockCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getStock()).asObject());

        // --- Purchase table bindings ---
        customerCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getCustomerName()));
        productCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getProductName()));
        quantityCol.setCellValueFactory(d -> new SimpleObjectProperty<>(d.getValue().getQuantity()));
        totalCol.setCellValueFactory(d -> new SimpleObjectProperty<>(d.getValue().getTotal()));
        paymentCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getPaymentMethod()));

        paymentMethodBox.setItems(FXCollections.observableArrayList("Cash", "UPI", "Card"));

        onLoadProducts();
        onLoadPurchases();
    }

    // --- Add Product ---
    @FXML
    public void onAddProduct() {
        try {
            // Validate inputs
            if (nameField.getText().isBlank() || priceField.getText().isBlank()) {
                addMsg.setText("⚠️ Name and Price are required!");
                return;
            }

            double price = Double.parseDouble(priceField.getText().trim());
            double stock = stockField.getText().isBlank() ? 0 : Double.parseDouble(stockField.getText().trim());

            Product p = new Product(
                    null,
                    nameField.getText().trim(),
                    typeField.getText().trim(),
                    hsnField.getText().trim(),
                    price,
                    unitField.getText().isBlank() ? "unit" : unitField.getText().trim(),
                    stock
            );

            boolean ok = productDAO.addProduct(p);
            if (ok) {
                addMsg.setText("✅ Product added successfully!");
                onLoadProducts();
                onClearForm();
            } else {
                addMsg.setText("❌ Database insert failed! Check ProductDAO.addProduct().");
            }
        } catch (NumberFormatException nfe) {
            addMsg.setText("⚠️ Invalid number format in Price or Stock!");
        } catch (Exception ex) {
            addMsg.setText("❌ Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // --- Delete product ---
    @FXML
    private void onDeleteProduct() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            addMsg.setText("⚠️ Select a product first!");
            return;
        }
        boolean deleted = productDAO.deleteProduct(selected.getName());
        if (deleted) {
            addMsg.setText("🗑️ Product deleted successfully!");
            onLoadProducts();
        } else {
            addMsg.setText("❌ Failed to delete product!");
        }
    }

    // --- Clear input fields ---
    @FXML
    public void onClearForm() {
        nameField.clear();
        typeField.clear();
        hsnField.clear();
        priceField.clear();
        unitField.clear();
        stockField.clear();
        addMsg.setText("");
    }

    // --- Load products ---
    @FXML
    public void onLoadProducts() {
        try {
            List<Product> list = productDAO.listAll();
            productTable.setItems(FXCollections.observableArrayList(list));
        } catch (Exception ex) {
            addMsg.setText("Error loading products: " + ex.getMessage());
        }
    }

    // --- Add Purchase ---
    @FXML
    public void onAddPurchase() {
        try {
            String customer = customerField.getText().trim();
            String product = purchaseProductField.getText().trim();
            int qty = Integer.parseInt(quantityField.getText().trim());
            String payment = paymentMethodBox.getValue();

            Product p = productDAO.findByName(product);
            if (p == null) {
                purchaseMsg.setText("❌ Product not found!");
                return;
            }

            double total = p.getUnitPrice() * qty;
            Purchase pur = new Purchase(customer, product, qty, total, payment);

            boolean ok = purchaseDAO.addPurchase(pur);
            purchaseMsg.setText(ok ? "✅ Purchase recorded!" : "❌ Failed to add purchase.");
            if (ok) {
                onLoadPurchases();
                customerField.clear();
                purchaseProductField.clear();
                quantityField.clear();
                paymentMethodBox.getSelectionModel().clearSelection();
            }
        } catch (NumberFormatException nfe) {
            purchaseMsg.setText("⚠️ Invalid quantity!");
        } catch (Exception e) {
            purchaseMsg.setText("Error: " + e.getMessage());
        }
    }

    // --- Load purchases ---
    @FXML
    public void onLoadPurchases() {
        try {
            List<Purchase> list = purchaseDAO.listAll();
            purchaseTable.setItems(FXCollections.observableArrayList(list));
        } catch (Exception ex) {
            purchaseMsg.setText("Error loading purchases: " + ex.getMessage());
        }
    }

    // --- Change password ---
    @FXML
    private void handleChangePassword() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Change Admin Password");
        dialog.setHeaderText("Enter new password");
        dialog.setContentText("New Password:");
        String newPass = dialog.showAndWait().orElse("");
        if (!newPass.isBlank()) {
            AdminAuth.changePassword(newPass);
            new Alert(Alert.AlertType.INFORMATION, "✅ Password updated!").showAndWait();
        } else {
            new Alert(Alert.AlertType.ERROR, "⚠️ Password cannot be empty!").showAndWait();
        }
    }
}
