package com.billingapp;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.application.Platform;

import java.sql.*;

// 🔍 For webcam + barcode reading
import com.github.sarxos.webcam.Webcam;
import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;

/**
 * User panel for viewing products, scanning barcodes, adding to cart, and printing receipts.
 */
public class UserPanelFX extends BorderPane {

    private ListView<String> cartList;
    private TextField searchField, qtyField, discountField, barcodeField;
    private TableView<Product> productTable;
    private ObservableList<Product> products;

    private boolean scanning = false;

    public UserPanelFX() {
        // 🔍 Search area (top)
       // 🧾 Customer + Search area (top)
VBox top = new VBox(10);

// --- Customer Info ---
HBox customerBox = new HBox(10);
TextField customerNameField = new TextField();
customerNameField.setPromptText("Customer Name");
TextField customerPhoneField = new TextField();
customerPhoneField.setPromptText("Phone Number");
customerBox.getChildren().addAll(new Label("Customer:"), customerNameField, new Label("Phone:"), customerPhoneField);

// --- Search ---
HBox searchBox = new HBox(10);
searchField = new TextField();
Button searchBtn = new Button("Search");
searchBox.getChildren().addAll(new Label("Search:"), searchField, searchBtn);

top.getChildren().addAll(customerBox, searchBox);


        // 🛒 Cart area (right)
        cartList = new ListView<>();
        VBox right = new VBox(10, new Label("Cart:"), cartList);

        // 📦 Product table (center)
        productTable = new TableView<>();

        TableColumn<Product, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));

        TableColumn<Product, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTextileType()));

        TableColumn<Product, Number> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getPrice()));

        TableColumn<Product, Number> stockCol = new TableColumn<>("Stock");
        stockCol.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getStock()));

        TableColumn<Product, Number> discountCol = new TableColumn<>("Discount (%)");
        discountCol.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getDiscount()));

        productTable.getColumns().addAll(nameCol, typeCol, priceCol, stockCol, discountCol);

        // 🔄 Load products from DB
        products = FXCollections.observableArrayList();
        loadProductsFromDB();
        productTable.setItems(products);

        // ➕ Quantity, Discount & Barcode input (bottom controls)
        HBox bottom = new HBox(10);
        qtyField = new TextField("1");
        qtyField.setPrefWidth(60);

        discountField = new TextField("0");
        discountField.setPrefWidth(80);

        barcodeField = new TextField();
        barcodeField.setPromptText("Scan or enter barcode");
        barcodeField.setPrefWidth(160);

        Button addBtn = new Button("Add to Cart");
        Button scanBarcodeBtn = new Button("📷 Scan Barcode");
        Button printBtn = new Button("🖨 Print Receipt");
        Button previewBtn = new Button("👁 Preview Receipt");

        bottom.getChildren().addAll(
                new Label("Qty:"), qtyField,
                new Label("Discount:"), discountField,
                barcodeField,
                addBtn,
                scanBarcodeBtn,
                printBtn,
                previewBtn
        );

        // 🛠 Add-to-cart manually
        addBtn.setOnAction(e -> {
            Product selected = productTable.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    int qty = Integer.parseInt(qtyField.getText().trim());
                    double extraDiscount = Double.parseDouble(discountField.getText().trim());
                    if (qty <= 0) return;

                    double totalDiscount = selected.getDiscount() + extraDiscount;
                    if (totalDiscount > 100) totalDiscount = 100;

                    double total = (selected.getPrice() * qty) * (1 - totalDiscount / 100);
                    String item = selected.getName() + " x" + qty +
                            " (Disc " + totalDiscount + "%) = ₹" +
                            String.format("%.2f", total);
                    cartList.getItems().add(item);

                } catch (NumberFormatException ex) {
                    new Alert(Alert.AlertType.ERROR, "Please enter valid numbers for Quantity and Discount.").showAndWait();
                }
            }
        });

        // 🏷 Barcode field (USB scanner or manual entry)
        barcodeField.setOnAction(e -> {
            String barcode = barcodeField.getText().trim();
            if (barcode.isEmpty()) return;

            Product found = ProductDAO.getProductByBarcode(barcode);
            if (found != null) {
                cartList.getItems().add(found.getName() + " x1 = ₹" + String.format("%.2f", found.getPrice()));
            } else {
                new Alert(Alert.AlertType.WARNING, "Product not found for barcode: " + barcode).showAndWait();
            }
            barcodeField.clear();
        });

        // 📷 Webcam barcode scanning
        scanBarcodeBtn.setOnAction(evt -> {
            if (scanning) {
                new Alert(Alert.AlertType.INFORMATION, "Barcode scanning is already running.").showAndWait();
                return;
            }

            scanning = true;

            new Thread(() -> {
                Webcam webcam = Webcam.getDefault();
                if (webcam == null) {
                    Platform.runLater(() -> new Alert(Alert.AlertType.ERROR, "No webcam detected!").showAndWait());
                    scanning = false;
                    return;
                }

                try {
                    webcam.open();
                    boolean found = false;
                    long start = System.currentTimeMillis();

                    while (!found && System.currentTimeMillis() - start < 15000) { // 15 seconds max
                        java.awt.image.BufferedImage img = webcam.getImage();
                        if (img == null) continue;

                        LuminanceSource source = new BufferedImageLuminanceSource(img);
                        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

                        try {
                            Result result = new MultiFormatReader().decode(bitmap);
                            if (result != null) {
                                found = true;
                                String barcode = result.getText();

                                Platform.runLater(() -> {
                                    Product foundProduct = ProductDAO.getProductByBarcode(barcode);
                                    if (foundProduct != null) {
                                        cartList.getItems().add(foundProduct.getName() + " x1 = ₹" +
                                                String.format("%.2f", foundProduct.getPrice()));
                                    } else {
                                        new Alert(Alert.AlertType.WARNING, "No product found for barcode: " + barcode).showAndWait();
                                    }
                                });
                            }
                        } catch (NotFoundException nf) {
                            // continue scanning
                        }

                        Thread.sleep(200);
                    }

                    if (!found) {
                        Platform.runLater(() -> new Alert(Alert.AlertType.INFORMATION, "No barcode detected!").showAndWait());
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                    Platform.runLater(() -> new Alert(Alert.AlertType.ERROR, "Error during scanning: " + ex.getMessage()).showAndWait());
                } finally {
                    webcam.close();
                    scanning = false;
                }
            }).start();
        });

        // 🖨 Print & Preview
printBtn.setOnAction(e -> {
    String name = customerNameField.getText().trim();
    String phone = customerPhoneField.getText().trim();
    PrinterUtils.printReceipt(cartList.getItems(), name, phone);
});

previewBtn.setOnAction(e -> {
    String name = customerNameField.getText().trim();
    String phone = customerPhoneField.getText().trim();
    ReceiptPreviewController.showPreview(cartList.getItems(), name, phone);
});


        // 🔍 Search products
        searchBtn.setOnAction(e -> searchProducts(searchField.getText().trim()));

        // 📌 Layout setup
        setTop(top);
        setRight(right);
        setCenter(productTable);
        setBottom(bottom);
    }

    // ======================================================
    // 🔧 Database methods
    // ======================================================

    private void loadProductsFromDB() {
        products.clear();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM products")) {

            while (rs.next()) {
                Product p = new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("textile_type"),
                        rs.getDouble("unit_price"),
                        rs.getDouble("stock"),
                        rs.getDouble("discount")
                );
                products.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Failed to load products: " + e.getMessage()).showAndWait();
        }
    }

    private void searchProducts(String keyword) {
        if (keyword.isEmpty()) {
            loadProductsFromDB();
            return;
        }
        products.clear();
        String sql = "SELECT * FROM products WHERE name LIKE ? OR textile_type LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product p = new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("textile_type"),
                        rs.getDouble("unit_price"),
                        rs.getDouble("stock"),
                        rs.getDouble("discount")
                );
                products.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "Search failed: " + e.getMessage()).showAndWait();
        }
    }
}
