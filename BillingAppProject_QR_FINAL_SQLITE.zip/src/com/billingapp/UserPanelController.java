package com.billingapp;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserPanelController {

    @FXML private ComboBox<String> customerTypeBox;
    @FXML private ComboBox<String> oldCustomerBox;
    @FXML private TextField customerNameField;
    @FXML private TextField customerPhoneField;
    @FXML private TextField searchProductField;

    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, String> productNameCol;
    @FXML private TableColumn<Product, String> productTypeCol;
    @FXML private TableColumn<Product, Double> productPriceCol;
    @FXML private TableColumn<Product, Double> productStockCol;

    @FXML private TableView<CartItem> cartTable;
    @FXML private TableColumn<CartItem, String> cartProductCol;
    @FXML private TableColumn<CartItem, Integer> cartQtyCol;
    @FXML private TableColumn<CartItem, Double> cartPriceCol;
    @FXML private TableColumn<CartItem, Double> cartTotalCol;
    @FXML private Label totalLabel;

    private ObservableList<CartItem> cartData = FXCollections.observableArrayList();
    private double total = 0.0;

    @FXML
    public void initialize() {
        if (customerTypeBox != null && customerTypeBox.getItems().isEmpty()) {
            customerTypeBox.getItems().addAll("New", "Old");
        }

        if (productNameCol != null) {
            productNameCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getName()));
            productTypeCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getTextileType()));
            productPriceCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getUnitPrice()).asObject());
            productStockCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getStock()).asObject());
        }

        if (cartProductCol != null) {
            cartProductCol.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getProduct()));
            cartQtyCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getQuantity()).asObject());
            cartPriceCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getPrice()).asObject());
            cartTotalCol.setCellValueFactory(d -> new SimpleDoubleProperty(d.getValue().getTotal()).asObject());
            cartTable.setItems(cartData);
        }
    }

    @FXML
    private void onLoadOldCustomers() {
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:database/billing.db");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT name, phone FROM customers")) {

            List<String> list = new ArrayList<>();
            while (rs.next()) {
                list.add(rs.getString("name") + " (" + rs.getString("phone") + ")");
            }
            oldCustomerBox.setItems(FXCollections.observableArrayList(list));

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load customers: " + e.getMessage());
        }
    }

    @FXML
    private void onSaveNewCustomer() {
        String name = customerNameField.getText().trim();
        String phone = customerPhoneField.getText().trim();
        if (name.isEmpty() || phone.isEmpty()) {
            showAlert("Validation", "Enter both name and phone.");
            return;
        }
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:database/billing.db");
             PreparedStatement ps = conn.prepareStatement("INSERT OR IGNORE INTO customers (name, phone) VALUES (?, ?)")) {
            ps.setString(1, name);
            ps.setString(2, phone);
            ps.executeUpdate();
            showAlert("Success", "Customer saved.");
            onLoadOldCustomers();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to save: " + e.getMessage());
        }
    }

    @FXML
    private void onSearchProduct() {
        String q = searchProductField.getText().trim().toLowerCase();
        System.out.println("Searching products for: " + q);
    }

    @FXML
    private void onAddToCart() {
        Product p = productTable.getSelectionModel().getSelectedItem();
        if (p == null) {
            showAlert("Select Product", "Please select a product first.");
            return;
        }
        int qty = 1;
        double price = p.getUnitPrice();
        double totalP = qty * price;
        cartData.add(new CartItem(p.getName(), qty, price, totalP));
        updateTotal();
    }

    private void updateTotal() {
        total = cartData.stream().mapToDouble(CartItem::getTotal).sum();
        totalLabel.setText(String.format("Total: ₹%.2f", total));
    }

    @FXML
    private void onGenerateBill() {
        if (cartData.isEmpty()) {
            showAlert("Empty Cart", "Add items to cart before billing.");
            return;
        }
        StringBuilder sb = new StringBuilder("🧾 BILL\n");
        sb.append("Customer: ").append(customerNameField.getText()).append(" (").append(customerPhoneField.getText()).append(")\n\n");
        for (CartItem it : cartData) {
            sb.append(String.format("%s x%d = ₹%.2f\n", it.getProduct(), it.getQuantity(), it.getTotal()));
        }
        sb.append("\n-------------------\n");
        sb.append(String.format("Total: ₹%.2f", total));
        showAlert("Generated Bill", sb.toString());
        cartData.clear();
        updateTotal();
    }

    private void showAlert(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setHeaderText(title);
        a.setContentText(msg);
        a.showAndWait();
    }
}
