package com.billingapp;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class ProductRow {
    private SimpleStringProperty product;
    private SimpleIntegerProperty qty;
    public ProductRow(String product, int qty) {
        this.product = new SimpleStringProperty(product);
        this.qty = new SimpleIntegerProperty(qty);
    }
    public String getProduct() { return product.get(); }
    public int getQty() { return qty.get(); }
    public void setProduct(String p) { product.set(p); }
    public void setQty(int q) { qty.set(q); }
}
