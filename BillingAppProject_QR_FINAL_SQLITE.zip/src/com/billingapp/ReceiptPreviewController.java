package com.billingapp;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.print.PrinterJob;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Controller for the Receipt Preview window.
 * Allows previewing and printing of the receipt content.
 * ✅ Updated to include Customer Name and Phone Number.
 */
public class ReceiptPreviewController {

    @FXML private TextArea receiptArea;
    @FXML private Button printButton;
    @FXML private Button closeButton;

    // Shared between scenes
    private static List<String> currentCart;
    private static String currentCustomerName = "";
    private static String currentCustomerPhone = "";

    /**
     * Opens the receipt preview window with cart items and optional customer info.
     */
    public static void showPreview(List<String> cart, String customerName, String phone) {
        if (cart == null || cart.isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "🛒 No items in cart to preview.").showAndWait();
            return;
        }

        currentCart = cart;
        currentCustomerName = (customerName != null) ? customerName.trim() : "";
        currentCustomerPhone = (phone != null) ? phone.trim() : "";

        try {
            FXMLLoader loader = new FXMLLoader(
                    ReceiptPreviewController.class.getResource("/com/billingapp/fxml/ReceiptPreview.fxml")
            );

            Scene scene = new Scene(loader.load());
            Stage stage = new Stage();
            stage.setTitle("🧾 Receipt Preview");
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "❌ Failed to load receipt preview window.").showAndWait();
        }
    }

    /**
     * Overloaded method for backward compatibility — when no customer info is passed.
     */
    public static void showPreview(List<String> cart) {
        showPreview(cart, "", "");
    }

    /**
     * Initializes the preview content once the FXML is loaded.
     */
    @FXML
    public void initialize() {
        if (currentCart != null && !currentCart.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            sb.append("====================================\n");
            sb.append("           BILLING RECEIPT          \n");
            sb.append("====================================\n\n");

            // 🧾 Add customer info
            if (!currentCustomerName.isEmpty()) {
                sb.append("Customer : ").append(currentCustomerName).append("\n");
            }
            if (!currentCustomerPhone.isEmpty()) {
                sb.append("Phone    : ").append(currentCustomerPhone).append("\n");
            }
            if (!currentCustomerName.isEmpty() || !currentCustomerPhone.isEmpty()) {
                sb.append("------------------------------------\n");
            }

            // 🛒 Add items
            for (String item : currentCart) {
                sb.append(item).append("\n");
            }

            // 📅 Footer info
            sb.append("\n------------------------------------\n");
            sb.append("Total Items: ").append(currentCart.size()).append("\n");
            sb.append("Date: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())).append("\n");
            sb.append("====================================\n");
            sb.append("       Thank You, Visit Again!      \n");
            sb.append("====================================\n");

            receiptArea.setText(sb.toString());
        } else {
            receiptArea.setText("🛒 Cart is empty. Nothing to preview.");
        }
    }

    /**
     * Closes the preview window.
     */
    @FXML
    private void onClose() {
        Stage stage = (Stage) receiptArea.getScene().getWindow();
        stage.close();
    }

    /**
     * Prints the current receipt preview.
     */
    @FXML
    private void onPrint() {
        if (receiptArea.getText().isBlank()) {
            new Alert(Alert.AlertType.WARNING, "⚠ No receipt content to print.").showAndWait();
            return;
        }

        try {
            PrinterJob job = PrinterJob.createPrinterJob();
            if (job != null && job.showPrintDialog(receiptArea.getScene().getWindow())) {
                boolean success = job.printPage(receiptArea);
                job.endJob();
                if (success) {
                    new Alert(Alert.AlertType.INFORMATION, "✅ Receipt printed successfully!").showAndWait();
                } else {
                    new Alert(Alert.AlertType.ERROR, "❌ Printing failed.").showAndWait();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            new Alert(Alert.AlertType.ERROR, "⚠ Error while printing: " + e.getMessage()).showAndWait();
        }
    }
}
