package com.billingapp;

import javafx.print.PrinterJob;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;

import java.awt.*;
import java.awt.print.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Utility class to handle printing or saving receipts.
 * Supports: JavaFX Printer → AWT Printer → File backup.
 * ✅ Now includes Customer Name & Phone details.
 */
public class PrinterUtils {

    /**
     * Legacy support — old calls without customer info.
     */
    public static void printReceipt(List<String> cart) {
        printReceipt(cart, "", "");
    }

    /**
     * Called from UserPanelFX to print or save a receipt.
     * @param cart List of items in the shopping cart
     * @param customerName Customer’s full name (optional)
     * @param phone Customer’s phone number (optional)
     */
    public static void printReceipt(List<String> cart, String customerName, String phone) {
        if (cart == null || cart.isEmpty()) {
            new Alert(Alert.AlertType.WARNING, "🛒 No items in the cart to print.").showAndWait();
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("====================================\n");
        sb.append("           BILLING RECEIPT          \n");
        sb.append("====================================\n\n");

        // 🧾 Customer Info
        if (customerName != null && !customerName.isEmpty()) {
            sb.append("Customer : ").append(customerName).append("\n");
        }
        if (phone != null && !phone.isEmpty()) {
            sb.append("Phone    : ").append(phone).append("\n");
        }
        if ((customerName != null && !customerName.isEmpty()) || (phone != null && !phone.isEmpty())) {
            sb.append("------------------------------------\n");
        }

        // 🛒 Cart Items
        for (String item : cart) {
            sb.append(item).append("\n");
        }

        // 📅 Footer info
        sb.append("\n------------------------------------\n");
        sb.append("Total Items: ").append(cart.size()).append("\n");
        sb.append("Date: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())).append("\n");
        sb.append("====================================\n");
        sb.append("        Thank You, Visit Again!     \n");
        sb.append("====================================\n");

        String text = sb.toString();

        // Try JavaFX printer first
        if (!printWithJavaFX(text)) {
            // Fallback: try AWT printer
            if (!printWithAWT(text)) {
                // Fallback: save as file
                saveReceiptToFile(text);
                new Alert(Alert.AlertType.INFORMATION,
                        "🖨️ Printing failed — saved as a text receipt instead.")
                        .showAndWait();
            }
        }
    }

    // ======================================================
    // 🔹 Option 1: JavaFX Printing (Primary)
    // ======================================================
    private static boolean printWithJavaFX(String text) {
        try {
            TextArea receiptArea = new TextArea(text);
            receiptArea.setEditable(false);

            PrinterJob job = PrinterJob.createPrinterJob();
            if (job != null && job.showPrintDialog(null)) {
                boolean success = job.printPage(receiptArea);
                job.endJob();
                if (success) {
                    System.out.println("✅ Printed successfully using JavaFX printer.");
                }
                return success;
            }
        } catch (Exception e) {
            System.err.println("⚠️ JavaFX printing failed: " + e.getMessage());
        }
        return false;
    }

    // ======================================================
    // 🔹 Option 2: AWT Printing (Backup)
    // ======================================================
    private static boolean printWithAWT(String text) {
        try {
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setJobName("Billing Receipt");

            job.setPrintable((Graphics g, PageFormat pf, int page) -> {
                Graphics2D g2 = (Graphics2D) g;
                g2.translate(pf.getImageableX(), pf.getImageableY());
                g2.setFont(new Font("Monospaced", Font.PLAIN, 10));

                String[] lines = text.split("\n");
                int lineHeight = g2.getFontMetrics().getHeight();
                int linesPerPage = (int) (pf.getImageableHeight() / lineHeight);
                int start = page * linesPerPage;

                if (start >= lines.length) return Printable.NO_SUCH_PAGE;

                int y;
                int end = Math.min(lines.length, start + linesPerPage);
                for (int i = start; i < end; i++) {
                    y = (i - start + 1) * lineHeight;
                    g2.drawString(lines[i], 0, y);
                }
                return Printable.PAGE_EXISTS;
            });

            if (job.printDialog()) {
                job.print();
                System.out.println("✅ Printed successfully using AWT printer.");
                return true;
            }
        } catch (Exception e) {
            System.err.println("⚠️ AWT printing failed: " + e.getMessage());
        }
        return false;
    }

    // ======================================================
    // 🔹 Option 3: Save to file if printing fails
    // ======================================================
    private static void saveReceiptToFile(String text) {
        try {
            Path dir = Paths.get("receipts");
            if (!Files.exists(dir)) Files.createDirectories(dir);

            String ts = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            Path file = dir.resolve("receipt_" + ts + ".txt");

            Files.write(file, text.getBytes());
            System.out.println("💾 Receipt saved at: " + file.toAbsolutePath());
        } catch (Exception e) {
            System.err.println("❌ Failed to save receipt: " + e.getMessage());
        }
    }
}
