package com.billingapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.net.URL;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) {
        TabPane tabs = new TabPane();

        try {
            // --- USER PANEL ---
            Tab userTab = new Tab("User");
            userTab.setClosable(false);

            try {
                // Load the User Panel FXML (if you have one)
                FXMLLoader userLoader = new FXMLLoader(getClass().getResource("/com/billingapp/fxml/user_panel.fxml"));
                Pane userRoot = userLoader.load();
                userTab.setContent(userRoot);
            } catch (Exception e) {
                // fallback: custom UserPanelFX class (if used instead of FXML)
                try {
                    userTab.setContent(new UserPanelFX());
                } catch (Exception ex) {
                    userTab.setContent(new Label("❌ Failed to load User Panel."));
                    ex.printStackTrace();
                }
            }

            // --- ADMIN PANEL ---
            Tab adminTab = new Tab("Admin");
            adminTab.setClosable(false);

            adminTab.setOnSelectionChanged(event -> {
                if (adminTab.isSelected() && adminTab.getContent() == null) {
                    handleAdminLogin(tabs, userTab, adminTab);
                }
            });

            tabs.getTabs().addAll(userTab, adminTab);

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Failed to load panels: " + e.getMessage());
        }

        // --- Scene setup ---
        Scene scene = new Scene(tabs, 900, 600);

        URL css = getClass().getResource("/com/billingapp/style.css");
        if (css != null) {
            scene.getStylesheets().add(css.toExternalForm());
        }

        stage.setTitle("Billing App - JavaFX");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Handles admin login prompt and loads admin panel if authenticated.
     */
    private void handleAdminLogin(TabPane tabs, Tab userTab, Tab adminTab) {
        LoginController temp = new LoginController();

        Dialog<String> dialog = new Dialog<>();
        dialog.setTitle("Admin Login");
        dialog.setHeaderText("Enter Admin Password");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.add(new Label("Password:"), 0, 0);
        grid.add(passwordField, 1, 0);
        dialog.getDialogPane().setContent(grid);

        ButtonType loginButtonType = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType changePassButtonType = new ButtonType("Change Password", ButtonBar.ButtonData.LEFT);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, changePassButtonType, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) return passwordField.getText();
            if (dialogButton == changePassButtonType) return "CHANGE";
            return null;
        });

        String result = dialog.showAndWait().orElse(null);

        if (result == null) {
            tabs.getSelectionModel().select(userTab);
            return;
        }

        if ("CHANGE".equals(result)) {
            temp.showChangePasswordDialog();
            tabs.getSelectionModel().select(userTab);
            return;
        }

        if (AdminAuth.checkPassword(result)) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/billingapp/fxml/admin_panel.fxml"));
                Pane adminRoot = loader.load();
                adminTab.setContent(adminRoot);
            } catch (Exception e) {
                e.printStackTrace();
                adminTab.setContent(new Label("❌ Failed to load Admin Panel."));
            }
        } else {
            new Alert(Alert.AlertType.ERROR, "❌ Incorrect password!").showAndWait();
            tabs.getSelectionModel().select(userTab);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
