package com.billingapp;

import java.sql.*;
import java.util.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * SQLite-backed ProductDAO.
 * Handles CRUD operations and logs receipts for sales.
 */
public class ProductDAO {
    private final Connection conn;

    public ProductDAO() {
        this.conn = DBConnection.getConnection();
        createTableIfNotExists();
    }

    public ProductDAO(Connection conn) {
        this.conn = conn;
        createTableIfNotExists();
    }

    // =================================================================
    //  Create Table (Prevents "no such table: products" errors)
    // =================================================================
    private void createTableIfNotExists() {
        String sql = """
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sku TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL UNIQUE,
                textile_type TEXT,
                hsn_sac TEXT,
                unit_price REAL,
                unit TEXT,
                stock REAL,
                discount REAL DEFAULT 0
            );
        """;
        try (Statement st = conn.createStatement()) {
            st.execute(sql);
        } catch (SQLException e) {
            System.err.println("⚠️ Failed to ensure 'products' table exists: " + e.getMessage());
        }
    }

    // =================================================================
    //  Add Product (Safe Insert)
    // =================================================================
    public boolean addProduct(Product p) {
        String sku = (p.getSku() == null || p.getSku().isBlank())
                ? "SKU-" + System.currentTimeMillis()
                : p.getSku();

        // Optional: Prevent duplicate names or SKUs
        if (getByName(p.getName()) != null) {
            System.err.println("⚠️ Product already exists with name: " + p.getName());
            return false;
        }

        String sql = """
            INSERT INTO products (sku, name, textile_type, hsn_sac, unit_price, unit, stock, discount)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, sku);
            ps.setString(2, p.getName());
            ps.setString(3, p.getTextileType());
            ps.setString(4, p.getHsnSac());
            ps.setDouble(5, p.getUnitPrice());
            ps.setString(6, p.getUnit());
            ps.setDouble(7, p.getStock());
            ps.setDouble(8, p.getDiscount());
            int rows = ps.executeUpdate();

            System.out.println("✅ Inserted product: " + p.getName() + " | Rows affected: " + rows);
            return rows == 1;
        } catch (SQLException ex) {
            System.err.println("❌ Error in addProduct(): " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    // =================================================================
    //  Add or Update (UPSERT)
    // =================================================================
    public boolean addOrUpdate(Product p) {
        String sql = """
            INSERT INTO products (sku, name, textile_type, hsn_sac, unit_price, unit, stock, discount)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(sku) DO UPDATE SET
                name = excluded.name,
                textile_type = excluded.textile_type,
                hsn_sac = excluded.hsn_sac,
                unit_price = excluded.unit_price,
                unit = excluded.unit,
                stock = excluded.stock,
                discount = excluded.discount
        """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getSku());
            ps.setString(2, p.getName());
            ps.setString(3, p.getTextileType());
            ps.setString(4, p.getHsnSac());
            ps.setDouble(5, p.getUnitPrice());
            ps.setString(6, p.getUnit());
            ps.setDouble(7, p.getStock());
            ps.setDouble(8, p.getDiscount());
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.err.println("❌ SQL Error in addOrUpdate(): " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    // =================================================================
    //  Delete by ID or Name
    // =================================================================
    public boolean delete(int id) {
        String sql = "DELETE FROM products WHERE id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("❌ SQL Error in delete(): " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    public boolean deleteProduct(String name) {
        String sql = "DELETE FROM products WHERE LOWER(name) = LOWER(?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("❌ SQL Error in deleteProduct(): " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    // =================================================================
    //  Get & List
    // =================================================================
    public List<Product> listAll() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM products ORDER BY id DESC";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapResultSet(rs));
        } catch (SQLException ex) {
            System.err.println("❌ SQL Error in listAll(): " + ex.getMessage());
            ex.printStackTrace();
        }
        return list;
    }

    public Product getByName(String name) {
        String sql = "SELECT * FROM products WHERE LOWER(name) = LOWER(?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapResultSet(rs);
            }
        } catch (SQLException ex) {
            System.err.println("❌ SQL Error in getByName(): " + ex.getMessage());
            ex.printStackTrace();
        }
        return null;
    }

    // =================================================================
    //  Stock & Logging
    // =================================================================
    public boolean reduceStock(int id, int qty) {
        String sql = "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, qty);
            ps.setInt(2, id);
            ps.setInt(3, qty);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            System.err.println("❌ SQL Error in reduceStock(): " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    public void logTransaction(String receipt) {
        try {
            File dir = new File("receipts");
            if (!dir.exists()) dir.mkdirs();
            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            File f = new File(dir, "receipt_" + ts + ".txt");
            try (FileWriter fw = new FileWriter(f)) {
                fw.write(receipt);
            }
        } catch (IOException e) {
            System.err.println("⚠️ Failed to save receipt: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // =================================================================
    //  Helper
    // =================================================================
    private Product mapResultSet(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setId(rs.getInt("id"));
        p.setSku(rs.getString("sku"));
        p.setName(rs.getString("name"));
        p.setTextileType(rs.getString("textile_type"));
        p.setHsnSac(rs.getString("hsn_sac"));
        p.setUnitPrice(rs.getDouble("unit_price"));
        p.setUnit(rs.getString("unit"));
        p.setStock(rs.getDouble("stock"));
        p.setDiscount(rs.getDouble("discount"));
        return p;
    }

    // ✅ Add this to ProductDAO.java
    // -------------------------------------------------------------
    public static Product getProductById(String id) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM products WHERE CAST(id AS TEXT)=? OR LOWER(name)=LOWER(?) OR LOWER(sku)=LOWER(?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, id);
                ps.setString(2, id);
                ps.setString(3, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        Product p = new Product();
                        p.setId(rs.getInt("id"));
                        p.setSku(rs.getString("sku"));
                        p.setName(rs.getString("name"));
                        p.setTextileType(rs.getString("textile_type"));
                        p.setHsnSac(rs.getString("hsn_sac"));
                        p.setUnitPrice(rs.getDouble("unit_price"));
                        p.setUnit(rs.getString("unit"));
                        p.setStock(rs.getDouble("stock"));
                        p.setDiscount(rs.getDouble("discount"));
                        return p;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error in getProductById(): " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }


    /**
     * Get product by barcode (added for barcode scanner support)
     */
    public static Product getProductByBarcode(String barcode) {
        if (barcode == null) return null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM products WHERE barcode = ?")) {
            ps.setString(1, barcode);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("textile_type"),
                        rs.getDouble("unit_price"),
                        rs.getDouble("stock"),
                        rs.getDouble("discount")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}