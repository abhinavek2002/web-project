package com.billingapp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class AdminPanel extends JPanel {
    private DefaultTableModel model;
    private JTable table;
    private JTextField nameF, priceF, stockF, discountF, searchF;

    // ✅ Instance of ProductDAO
    private final ProductDAO productDAO = new ProductDAO();

    public AdminPanel() {
        // 🔹 Apply Nimbus Look & Feel once
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            System.err.println("Nimbus not available, using default.");
        }

        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setBackground(new Color(245, 250, 255));

        // Table Model
        model = new DefaultTableModel(new Object[]{"ID", "Name", "Price", "Stock", "Discount"}, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(model);
        table.setFillsViewportHeight(true);
        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(Color.WHITE);

        // 🔹 Top search bar
        JPanel top = new JPanel();
        top.setBackground(new Color(220, 235, 250));
        searchF = new JTextField(15);
        JButton searchB = new JButton("Search");
        searchB.addActionListener(e -> loadProducts(searchF.getText().trim()));
        top.add(new JLabel("Search:"));
        top.add(searchF);
        top.add(searchB);

        // 🔹 Bottom form
        JPanel form = new JPanel(new GridLayout(2, 5, 8, 8));
        form.setBackground(new Color(235, 245, 255));

        nameF = new JTextField();
        priceF = new JTextField();
        stockF = new JTextField();
        discountF = new JTextField();

        JButton addB = new JButton("Add / Update");
        JButton delB = new JButton("Delete");

        // Save / Update button
        addB.addActionListener(e -> {
            try {
                String name = nameF.getText().trim();
                if (name.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Name cannot be empty");
                    return;
                }
                double price = Double.parseDouble(priceF.getText().trim());
                double stock = Double.parseDouble(stockF.getText().trim()); // ✅ use double
                double disc = Double.parseDouble(discountF.getText().trim());

                Product p = new Product(0, name, price, stock, disc);
                productDAO.addOrUpdate(p);

                loadProducts("");
                clearForm();
                JOptionPane.showMessageDialog(this, "Saved successfully.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid number input. Check price, stock, or discount.");
            } catch (Exception ex) { // ✅ now catches any error
                JOptionPane.showMessageDialog(this, "Error saving product: " + ex.getMessage());
            }
        });

        // Delete button
        delB.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r >= 0) {
                int confirm = JOptionPane.showConfirmDialog(this, "Delete selected product?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int id = (int) model.getValueAt(r, 0);
                    try {
                        productDAO.delete(id); // ✅ wrapped in try-catch
                        loadProducts("");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Error deleting product: " + ex.getMessage());
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Select a product to delete.");
            }
        });

        // Labels Row
        form.add(new JLabel("Name"));
        form.add(new JLabel("Price"));
        form.add(new JLabel("Stock"));
        form.add(new JLabel("Discount"));
        form.add(new JLabel(""));

        // Input Row
        form.add(nameF);
        form.add(priceF);
        form.add(stockF);
        form.add(discountF);

        JPanel bb = new JPanel();
        bb.setBackground(new Color(235, 245, 255));
        bb.add(addB);
        bb.add(delB);
        form.add(bb);

        // Add components
        add(top, BorderLayout.NORTH);
        add(sp, BorderLayout.CENTER);
        add(form, BorderLayout.SOUTH);

        // Table row click → load product to form
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int r = table.getSelectedRow();
                if (r >= 0) {
                    nameF.setText(model.getValueAt(r, 1).toString());
                    priceF.setText(model.getValueAt(r, 2).toString());
                    stockF.setText(model.getValueAt(r, 3).toString());
                    discountF.setText(model.getValueAt(r, 4).toString());
                }
            }
        });

        loadProducts("");
    }

    private void clearForm() {
        nameF.setText("");
        priceF.setText("");
        stockF.setText("");
        discountF.setText("");
    }

    private void loadProducts(String q) {
        model.setRowCount(0);
        try {
            List<Product> list = (q == null || q.isEmpty()) ? productDAO.listAll() : productDAO.search(q);
            for (Product p : list) {
                model.addRow(new Object[]{
                        p.getId(),
                        p.getName(),
                        p.getPrice(),
                        p.getStock(),
                        p.getDiscount()
                });
            }
        } catch (Exception ex) { // ✅ simplified
            JOptionPane.showMessageDialog(this, "Error loading products: " + ex.getMessage());
        }
    }
}
