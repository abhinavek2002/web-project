package com.billingapp;

public class Purchase {
    private String customerName;
    private String productName;
    private int quantity;
    private double total;
    private String paymentMethod;

    public Purchase(String customerName, String productName, int quantity, double total, String paymentMethod) {
        this.customerName = customerName;
        this.productName = productName;
        this.quantity = quantity;
        this.total = total;
        this.paymentMethod = paymentMethod;
    }

    public String getCustomerName() { return customerName; }
    public String getProductName() { return productName; }
    public int getQuantity() { return quantity; }
    public double getTotal() { return total; }
    public String getPaymentMethod() { return paymentMethod; }
}
