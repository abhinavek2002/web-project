package com.billingapp;

import javafx.scene.layout.BorderPane;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class AdminPanelFX extends BorderPane {

    private TableView<Product> table;
    private ObservableList<Product> products;

    public AdminPanelFX() {
        table = new TableView<>();
        products = FXCollections.observableArrayList();

        // --- Name Column ---
        TableColumn<Product, String> nameCol = new TableColumn<>("Name");
        nameCol.setCellValueFactory(c -> 
            new SimpleStringProperty(c.getValue().getName())
        );

        // --- Price Column ---
        TableColumn<Product, Number> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(c -> 
            new SimpleDoubleProperty(c.getValue().getPrice())
        );

        // --- Stock Column ---
        TableColumn<Product, Number> stockCol = new TableColumn<>("Stock");
            stockCol.setCellValueFactory(c -> 
                new SimpleIntegerProperty((int) c.getValue().getStock()) // 👈 cast to int for constructor
            );

        // Add all columns
        table.getColumns().addAll(nameCol, priceCol, stockCol);

        // Bind data
        table.setItems(products);

        // Add to layout
        setCenter(table);
    }
}
