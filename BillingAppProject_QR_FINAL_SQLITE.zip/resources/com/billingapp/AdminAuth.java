package com.billingapp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Handles Admin password storage and verification.
 * Default password is "admin123".
 * Password is stored in a local file so it persists across restarts.
 */
public class AdminAuth {

    private static final String FILE_NAME = "admin.pass"; // password storage file
    private static String ADMIN_PASSWORD = "admin123";    // default password

    // --- Load saved password when class is first used ---
    static {
        loadPassword();
    }

    /**
     * Load password from file if exists.
     */
    private static void loadPassword() {
        try {
            Path path = Paths.get(FILE_NAME);
            if (Files.exists(path)) {
                ADMIN_PASSWORD = Files.readString(path).trim();
            } else {
                // If no file exists, create one with the default password
                savePassword();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Save current password into file.
     */
    private static void savePassword() {
        try {
            Files.write(Paths.get(FILE_NAME), ADMIN_PASSWORD.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * ✅ Check entered password (used in LoginController)
     */
    public static boolean checkPassword(String input) {
        return input != null && input.equals(ADMIN_PASSWORD);
    }

    /**
     * ✅ Verify password (used in the new dialog-based Change Password)
     */
    public static boolean verifyPassword(String input) {
        return checkPassword(input);
    }

    /**
     * ✅ Change admin password and persist it.
     */
    public static void changePassword(String newPassword) {
        if (newPassword != null && !newPassword.isBlank()) {
            ADMIN_PASSWORD = newPassword;
            savePassword();
        }
    }
}
