package com.billingapp;

import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.IOException;
import java.util.Map;

/**
 * ExampleController shows how to integrate CustomerManager.
 */
public class ExampleController {

    @FXML private TextField nameField;
    @FXML private TextField phoneField;
    @FXML private TextField searchField;
    @FXML private Label statusLabel;

    private final String customersFile = "customers.txt"; // relative to working dir

    @FXML
    public void onSave() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        if (name.isEmpty() || phone.isEmpty()) {
            statusLabel.setText("Enter both name and phone.");
            return;
        }
        try {
            CustomerManager.saveCustomer(name, phone, customersFile);
            statusLabel.setText("Saved customer: " + name);
        } catch (IOException e) {
            statusLabel.setText("Error saving: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    public void onSearch() {
        String q = searchField.getText().trim();
        if (q.isEmpty()) {
            statusLabel.setText("Enter name or phone to search.");
            return;
        }
        try {
            Map<String,String> found = CustomerManager.findCustomer(q, customersFile);
            if (found != null) {
                nameField.setText(found.get("name"));
                phoneField.setText(found.get("phone"));
                statusLabel.setText("Found: " + found.get("name"));
            } else {
                statusLabel.setText("No matching customer found.");
            }
        } catch (IOException e) {
            statusLabel.setText("Error searching: " + e.getMessage());
            e.printStackTrace();
        }
    }
}